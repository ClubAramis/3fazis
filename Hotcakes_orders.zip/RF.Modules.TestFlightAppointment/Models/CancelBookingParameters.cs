﻿namespace RF.Modules.TestFlightAppointment.Models
{
    public class CancelBookingParameters
    {
        public int BookingID { get; set; }
    }
}